from django.contrib import admin
from .models import DetalheTurma

admin.site.register(DetalheTurma)